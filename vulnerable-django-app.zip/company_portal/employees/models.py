from django.contrib.auth.models import User
from django.db import models

class EmployeeProfile(models.Model):
    ROLE_CHOICES = [
        ("DEV", "Developer"),
        ("SEC", "Security"),
        ("HR", "HR"),
        ("OPS", "Operations"),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    resume = models.FileField(upload_to="uploads/")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.username

