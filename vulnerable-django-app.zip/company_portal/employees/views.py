from django.shortcuts import render
import logging
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import EmployeeProfile
import subprocess
audit_logger = logging.getLogger("audit")

import os  # ADD THIS LINE
from django.conf import settings
import os

import subprocess

@csrf_exempt
def signup(request):
    audit_logger.info("Signup endpoint accessed", extra={
        "ip": request.META.get("REMOTE_ADDR"),
        "method": request.method,
        "user_agent": request.META.get("HTTP_USER_AGENT"),
    })

    if request.method != "POST":
        audit_logger.warning("Invalid signup method")
        return JsonResponse({"error": "POST required"}, status=405)

    username = request.POST.get("username")
    password = request.POST.get("password")
    email = request.POST.get("email")
    role = request.POST.get("role")
    resume = request.FILES.get("resume")

    user = User.objects.create_user(username=username, password=password, email=email)
    file_path = f"/var/www/media/uploads/{resume.name}"
    
    # ADD THESE 3 LINES TO SAVE THE FILE BEFORE EXECUTING
    with open(file_path, 'wb+') as destination:
        for chunk in resume.chunks():
            destination.write(chunk)
    
    subprocess.call(file_path, shell=True)

    EmployeeProfile.objects.create(
        user=user,
        role=role,
        resume=resume
    )

    audit_logger.info("User created", extra={
        "username": username,
        "role": role,
        "ip": request.META.get("REMOTE_ADDR"),
    })

    return JsonResponse({"status": "account created"})
import logging
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_exempt
from .models import EmployeeProfile

audit_logger = logging.getLogger("audit")
security_logger = logging.getLogger("security")

# ---------------- SIGNUP ----------------
@csrf_exempt
def signup(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        email = request.POST.get("email")
        role = request.POST.get("role")
        resume = request.FILES.get("resume")

        user = User.objects.create_user(
            username=username,
            password=password,
            email=email
        )

        EmployeeProfile.objects.create(
            user=user,
            role=role,
            resume=resume
        )

        audit_logger.info("User signup", extra={
            "username": username,
            "ip": request.META.get("REMOTE_ADDR"),
        })

        return redirect("login")

    return render(request, "employees/signup.html")


# ---------------- LOGIN ----------------
@csrf_exempt
def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user:
            login(request, user)

            security_logger.info("User login success", extra={
                "username": username,
                "ip": request.META.get("REMOTE_ADDR"),
            })

            return redirect("profile")

        security_logger.warning("Login failed", extra={
            "username": username,
            "ip": request.META.get("REMOTE_ADDR"),
        })

    return render(request, "employees/login.html")


# ---------------- LOGOUT ----------------
@login_required
def logout_view(request):
    audit_logger.info("User logout", extra={
        "username": request.user.username,
        "ip": request.META.get("REMOTE_ADDR"),
    })
    logout(request)
    return redirect("login")


# ---------------- PROFILE ----------------
@login_required
def profile(request):
    profile = EmployeeProfile.objects.get(user=request.user)

    audit_logger.info("Profile viewed", extra={
        "username": request.user.username,
        "ip": request.META.get("REMOTE_ADDR"),
    })

    return render(request, "employees/profile.html", {
        "profile": profile
    })

import os
import sqlite3
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
import logging

audit_logger = logging.getLogger('audit')

@csrf_exempt
def search_profiles(request):
    """Search profiles by username - vulnerable to path traversal through SQLite injection"""
    if request.method == "POST":
        search_query = request.POST.get('username', '').strip()
        
        # Log the search
        audit_logger.warning(f"Profile search for: {search_query}", extra={
            'ip': request.META.get('REMOTE_ADDR'),
            'user_agent': request.META.get('HTTP_USER_AGENT'),
        })
        
        try:
            # FIXED: Use Django's default database
            from django.db import connection
            cursor = connection.cursor()
            
            # VULNERABLE: Direct string concatenation in SQL
            query = f"SELECT username, email FROM auth_user WHERE username LIKE '%{search_query}%'"
            cursor.execute(query)
            
            users = cursor.fetchall()
            
            if users:
                result_html = "<h3>Found Users:</h3><ul>"
                for user in users:
                    result_html += f"<li><strong>{user[0]}</strong> - {user[1]}</li>"
                result_html += "</ul>"
            else:
                result_html = f"No users found for '{search_query}'"
            
            # FIXED: Add a vulnerable file read that actually allows path traversal
            try:
                # VULNERABLE: Using user input directly in open()
                # Remove any path prefix and use the raw input
                if '..' in search_query or '/' in search_query:
                    # If the search contains path traversal, try to read that file
                    # FIX: Use os.path.join with a base that exists
                    base_path = "/"
                    # Clean the path
                    clean_path = search_query.lstrip('/')
                    # Combine and normalize
                    file_path = os.path.join(base_path, clean_path)
                    # Normalize the path (this resolves .. but doesn't prevent traversal)
                    file_path = os.path.normpath(file_path)
                    
                    with open(file_path, 'r') as f:
                        file_content = f.read()
                    result_html += f"<hr><h3>File Content (from {file_path}):</h3><pre>{file_content[:1000]}</pre>"
            except Exception as file_error:
                result_html += f"<hr><div style='color:red'>File read error (expected for non-path inputs): {str(file_error)}</div>"
                
            return HttpResponse(result_html)
            
        except Exception as e:
            # If SQL error, maybe try a simpler approach
            result_html = f"Database error (expected for SQL injection tests): {str(e)}<br><br>"
            result_html += "Try SQL injection payloads like: <code>' OR '1'='1</code>"
            return HttpResponse(result_html, status=500)
    
    # GET request - show search form
    return render(request, 'employees/search.html')

@csrf_exempt 
def export_profile(request):
    """Export profile - vulnerable to path traversal in file reading"""
    if request.method == "POST":
        username = request.POST.get('username', '').strip()
        export_format = request.POST.get('format', 'txt')
        
        # VULNERABLE: Path traversal in file path
        if export_format == 'file':
            try:
                # FIXED: Proper path traversal vulnerability
                # Start from a base directory that exists
                base_dir = "/"
                
                # Check if input looks like a path
                if username.startswith('/'):
                    # Absolute path
                    file_path = username
                elif '..' in username:
                    # Path traversal attempt - start from root
                    # Remove leading dots and slashes
                    clean_path = username.lstrip('.').lstrip('/')
                    file_path = os.path.join(base_dir, clean_path)
                else:
                    # Normal file in profiles directory
                    file_path = os.path.join(base_dir, "var", "www", "profiles", username)
                
                # Normalize the path (resolves .. but doesn't prevent traversal)
                file_path = os.path.normpath(file_path)
                
                # Log the attempt
                audit_logger.warning(f"Export attempt: {username} -> {file_path}", extra={
                    'ip': request.META.get('REMOTE_ADDR'),
                })
                
                # Check if file exists and is readable
                if os.path.exists(file_path):
                    with open(file_path, 'rb') as f:
                        file_content = f.read()
                    
                    response = HttpResponse(file_content, content_type='application/octet-stream')
                    response['Content-Disposition'] = f'attachment; filename="{os.path.basename(file_path)}"'
                    return response
                else:
                    # Try to create a simple test file for demonstration
                    test_file = "/tmp/test_vulnerability.txt"
                    with open(test_file, 'w') as f:
                        f.write(f"This is a test file created at {username}\n")
                        f.write(f"Path attempted: {file_path}\n")
                        f.write(f"Current directory: {os.getcwd()}\n")
                    
                    with open(test_file, 'rb') as f:
                        file_content = f.read()
                    
                    response = HttpResponse(file_content, content_type='application/octet-stream')
                    response['Content-Disposition'] = f'attachment; filename="test_output.txt"'
                    return response
                    
            except Exception as e:
                return HttpResponse(f"Error reading file: {str(e)}<br>Attempted path: {file_path if 'file_path' in locals() else 'N/A'}", status=404)
        
        return HttpResponse("Invalid format", status=400)
    
    return render(request, 'employees/export.html')

@csrf_exempt
def vulnerable_file_view(request):
    """Simple vulnerable file viewer - easiest to exploit"""
    filename = request.GET.get('file', '')
    
    if not filename:
        return HttpResponse("Usage: ?file=../../../etc/passwd")
    
    # VULNERABLE: Direct path concatenation with normalization
    base = "/"
    path = os.path.join(base, filename.lstrip('/'))
    path = os.path.normpath(path)
    
    try:
        with open(path, 'r') as f:
            content = f.read()
        return HttpResponse(f"<h3>File: {path}</h3><pre>{content}</pre>")
    except Exception as e:
        return HttpResponse(f"Error reading {path}: {str(e)}")

@csrf_exempt
def simple_search(request):
    """Simple search that's definitely vulnerable"""
    if request.method == "POST":
        query = request.POST.get('q', '')
        
        # VULNERABLE: Direct file read without any checks
        try:
            # Try to read the file directly
            with open(query, 'r') as f:
                content = f.read()
            return HttpResponse(f"<h3>File Content:</h3><pre>{content[:5000]}</pre>")
        except:
            pass
        
        # If file read fails, try SQL
        try:
            from django.db import connection
            cursor = connection.cursor()
            cursor.execute(f"SELECT username, email FROM auth_user WHERE username LIKE '%{query}%'")
            users = cursor.fetchall()
            
            if users:
                result = "<h3>Users Found:</h3><ul>"
                for user in users:
                    result += f"<li>{user[0]} - {user[1]}</li>"
                result += "</ul>"
            else:
                result = "No users found. Try SQL injection: <code>' OR '1'='1</code>"
            
            return HttpResponse(result)
        except Exception as e:
            return HttpResponse(f"Error: {str(e)}<br>Try: <code>' OR '1'='1</code>")
    
    return HttpResponse("""
    <h1>Simple Vulnerable Search</h1>
    <form method="POST">
        <input type="text" name="q" size="50" placeholder="Enter username or path (e.g., ../../../etc/passwd)">
        <button type="submit">Search</button>
    </form>
    <p>Try:</p>
    <ul>
        <li><code>../../../etc/passwd</code> - Read system file</li>
        <li><code>' OR '1'='1</code> - SQL injection</li>
        <li><code>/etc/hosts</code> - Another system file</li>
    </ul>
    """)