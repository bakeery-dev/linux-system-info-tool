import logging
import time

logger = logging.getLogger("security")

class FullRequestLoggingMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        start = time.time()

        response = self.get_response(request)

        duration = round(time.time() - start, 4)

        logger.info("HTTP_REQUEST", extra={
            "ip": request.META.get("REMOTE_ADDR"),
            "method": request.method,
            "path": request.get_full_path(),
            "status": response.status_code,
            "user": str(request.user) if request.user.is_authenticated else "anonymous",
            "user_agent": request.META.get("HTTP_USER_AGENT"),
            "content_type": request.META.get("CONTENT_TYPE"),
            "duration": duration,
        })

        return response

