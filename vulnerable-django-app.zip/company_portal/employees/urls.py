from django.urls import path
from . import views

urlpatterns = [
    path("signup/", views.signup, name="signup"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("profile/", views.profile, name="profile"),
    path('search/', views.search_profiles, name='search_profiles'),
    path('export/', views.export_profile, name='export_profile'),
    path('vulnerable/', views.vulnerable_file_view, name='vulnerable_file'),

]

